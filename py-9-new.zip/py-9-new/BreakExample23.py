for i in range(1,11):
    pass
else:
    pass



print("hi")
