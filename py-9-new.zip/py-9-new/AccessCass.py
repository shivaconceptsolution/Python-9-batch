from Overriding import AndroidPhoneNew

obj = AndroidPhoneNew()
obj.screen()
obj.multimedia()
obj.software()
obj.hardware()
