for k in range(1,10):

  for i in range(5,1,-1):  #4
      for j in range(1,i):  #(5,4)
        print("*",end=' ')   # print the data in same row

      print()  #new line   
