s = "Fail"

try:
  a = int(input("Enter First Number"))
  b = int(input("Enter Second Number"))
  c = a/b
  print(c)
  s = "Success"

except ValueError:
  print("Enter only numeric value")

except ZeroDivisionError:
  print("Denominator can not be zero")

except NameError:
  print("Write proper syntax format")
else:
    print("NO any Error on this program")

finally:
    print("Program executed with "+s) 


  
  
