# WAP to check prime number without using third variable
num= int(input("Enter any number")) #9
i=2
if num>2:
    if num%2==0:
        print("not prime")
    else:    
      while i<num//2:
         if num%i==0:
            print("not prime")
            break
         i=i+1 
      if num//2 == i or num==2 or num==3:
        print("prime")

