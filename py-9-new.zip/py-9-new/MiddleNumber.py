num = 175
a = (num//10)%10   # 17%10  #7

print(a)
