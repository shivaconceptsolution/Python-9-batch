import threading
import time
def table(num):
    for i in range(1,11):
            print(str(num*i) + " ")
            time.sleep(1)


t = threading.Thread(target=table(5))
t.start()

t1 = threading.Thread(target=table(9))
t1.start()
