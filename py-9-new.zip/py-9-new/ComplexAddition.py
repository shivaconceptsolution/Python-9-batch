a = 2+3j
print(type(a).__name__)
b = 4+5j
c = a+b
print(c)
c = a*b
print(c)

print(ord('X'))

print(chr(76))
