for i in range(1,10):
    pass
if i%2:
    pass
else:
    pass

def fun():
    pass

class Hello:
    pass
