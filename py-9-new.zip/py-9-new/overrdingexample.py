class AndroidPhone:
    def screen(self):
        print("screen size")

    def multimedia(self):
        print("multimedia")

    def software(self):
        print("nougat")

    def hardware(self):
        print("hardware")


class AndroidPhoneNew(AndroidPhone):
    def screen(self):
        print("new Screen")

    def software(self):
        super().software()
        print("orio")



obj = AndroidPhoneNew()
obj.screen()
obj.multimedia()
obj.software()
obj.hardware()
