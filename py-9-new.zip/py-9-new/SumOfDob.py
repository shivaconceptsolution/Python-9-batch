dob = int(input("Enter date of birth in ddmmyyyy"))
a = dob%10    # 2
dob = dob//10  # 1001199
b = dob%10    # 9
dob = dob//10  #100119
c = dob%10   #9
dob = dob//10  #10011
d = dob%10   #1
dob = dob//10  #1001
e = dob%10    #1
dob = dob//10  #100
f = dob%10    #0
dob = dob//10  #10
g = dob%10    #0
h = dob//10  #1
s = a+b+c+d+e+f+g+h
print(s)
