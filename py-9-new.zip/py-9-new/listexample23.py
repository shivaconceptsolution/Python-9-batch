ls = []
size = int(input("Enter number of items in list"))
for i in range(0,size):
    item  = int(input("Enter element into list"))
    ls.append(item)

print(ls)    
