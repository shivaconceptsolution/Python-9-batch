import A

def fun2():
    print("New Features")

obj = A.A()
obj.fun=fun2
obj.fun()
