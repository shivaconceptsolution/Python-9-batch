class ListReverse:
    def accept(self,x):
        self.x = x

    def logic(self):
        self.lst=[]
        for i in range(len(self.x)-1,-1,-1):
           self.lst.append(self.x[i])
            
    def display(self):
       print(self.lst)

obj = ListReverse()
obj.accept([1,2,3,4,5])
obj.logic()
obj.display()


       
