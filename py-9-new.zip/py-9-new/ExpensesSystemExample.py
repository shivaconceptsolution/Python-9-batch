import time
f = open("expenses.txt","a+")
expenseby = input("Enter expense by")
grocerry = input("Enter grocerry details")
milk = input("Enter milk expenses")
rent = input("Enter rent expenses")
date = time.asctime(time.localtime(time.time()))
f.write("\n Today Expenses Details")
f.write("\n")
f.write("Name:"+expenseby)
f.write("\n")
f.write("Grocerry:"+grocerry)
f.write("\n")
f.write("Milk:" +milk)
f.write("\n")
f.write("Rent:" +rent)
f.write("\n")
f.write("Date:" + date)
f.seek(0)
data = f.readlines()
s=0
for d in data:
    print(d)
    if d[0]=='G' or d[0]=='R' or d[0] == 'M':
       s = s + int(d[d.find(':')+1:])
      
print("Total Expenses is ",s)
f.close()
