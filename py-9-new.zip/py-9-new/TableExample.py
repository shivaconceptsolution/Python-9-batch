num=9
for i in range(1,11):
    print(num*i)
    if i==5:
        break
else:
    print(i)
