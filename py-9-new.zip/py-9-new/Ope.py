class Ope:
    def __init__(self,num):
        self.num= num
    def __add__(self,other):
        self.num=(self.num+other.num)+((self.num+other.num)*(18/100))
        return Ope(self.num)

    def __str__(self):
       return str(self.num)


o = Ope(10000)
p = Ope(20000)
t = o + p
print(t)






    
        
        
