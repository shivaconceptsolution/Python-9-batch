import time
print(time.time())
print(time.localtime(time.time()))
print(time.asctime(time.localtime(time.time())))

d = time.localtime(time.time())
print(str(d.tm_year) + ":"+ str(d.tm_mon) + ":" + str(d.tm_mday))

