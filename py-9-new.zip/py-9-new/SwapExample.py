class Swap:

 def swap():

  a,b=10,2
  a,b = b,a
  print(a,b)

Swap.swap()
