num=5
i=2
f = True
while f:
   if num == i:
       f=False
       print("prime")
   elif num%i==0:
       print("Not Prime")
       break
   
   i=i+1   

