from AdminModule import Admin

class Employee(Admin):
    def __init__(self):
        super().__init__()
    def fun(self):
        print("Welcome in Employee Module")
    def Accept1(self,sal):
        super().Accept(1001,"EMP1")
        self.sal=sal

    def Display1(self):
        super().Display()
        print("Salary is ",self.sal)
