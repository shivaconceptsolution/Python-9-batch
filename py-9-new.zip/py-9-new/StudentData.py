student = {"A":{"rno":[1001,1003,1005],"sname":["Manish","Jay","Ravi"]},"B":{"rno":[2001,2003,2005],"sname":["Sachin","Vijay","Kavi"]}}
print(student["A"]["rno"][2])
for s in student:
    print(s,end=' ')
    for d in student[s]:
        for e in student[s][d]:
          print(e,end=' ')
    print()    
           
