class SalaryException(Exception):
    pass 

try:
    sal = int(input("Enter salary"))
    if sal<10000:
        raise SalaryException
    print("Salary is "+str(sal))
except SalaryException:
    print("Salary should be > 10000")


   
