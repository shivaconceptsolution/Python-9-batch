from abc import ABC,abstractmethod

class Area(ABC):
    @abstractmethod
    def rectangle(self):
        pass
    @abstractmethod
    def triangle(self):
        pass

class ImplArea(Area):
    def rectangle(self):
        w=5000
        h=200
        area = w*h
        print(area)
    def triangle(self):
        w=5000
        h=200
        area = (w/h)/2
        print(area) 


obj = ImplArea()
obj.rectangle()


