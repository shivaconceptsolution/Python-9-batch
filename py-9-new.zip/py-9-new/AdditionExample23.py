addition= lambda x=[1,2,3]:list(str(x[0]**2)) + list(str(x[1]**2))



