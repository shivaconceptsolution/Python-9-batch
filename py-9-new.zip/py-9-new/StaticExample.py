class StaticExample:
    a=10
    b=20
    def additionExample():
        print(StaticExample.a+StaticExample.b)


StaticExample.additionExample()
