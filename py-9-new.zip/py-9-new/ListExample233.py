x = [12,'A',True,12.345]
y = [12,12,34,45,67,78,None]

print(x,y[len(y)-1:])
print("X LIST")
for i in x:
    print(i)

print("Y LIST")
for j in y:
    print(j)

z=[]
for i in range(65,71):
    z.append(chr(i))

del z[1:3]
print(z)
print(z[::-1])

print(z[::-3])


