for i in range(1,11):
    if i==3 or i==5:
        continue
    if i==3:
        break
    print(i)


