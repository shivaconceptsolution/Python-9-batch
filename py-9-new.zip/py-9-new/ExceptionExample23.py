class NegativeException(Exception):
    pass

try:
    num=int(input("Enter First Number"))
    if num<0:
        raise NegativeException

except NegativeException:
    print("Enter only positive data")
