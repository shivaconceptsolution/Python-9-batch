num = int(input("enter number"))
s=''
while num!=0:
    s=s+str(num%10)
    num=num//10
else:
    print(s)
