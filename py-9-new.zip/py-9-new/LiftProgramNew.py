import time
i=1

while i<=20:
    
    if i<=5:
        print(i)
    elif i<=10:
        print(11-i)
    elif i<=15:
        print(i-10)
    else:
        print(21-i)

    i=i+1    
    time.sleep(1)
