while True:
  s = "success"
  try:
    a = int(input("Enter First Number"))
    b = int(input("Enter Second Number"))
    c = a/b
    print(c)
  except ZeroDivisionError:
    print("Denominator can not be zero")
    s = "fail"
  except ValueError:
    print("Enter only numeric data")
    s = "fail"
  else:
    s = "no any exception problem"
    break
  finally:
    print(s)



