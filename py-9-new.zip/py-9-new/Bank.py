class Bank:
    
    def __init__(self):
        self.balance=5000
    def __debit(self,amt):
        self.balance-=amt
    def __credit(self,amt):
        self.balance+=amt
    def __checkbalance(self):
        print("balance is "+str(self.balance))
    def login(self,pin): #transction part encapsulated by login
        if pin == 1234:
            self.__debit(1000)
            self.__checkbalance()
        else:
            print("Invalid Pin Code")
        

obj= Bank()
obj.login(1234)

              
              
        
