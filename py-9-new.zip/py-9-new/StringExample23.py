s = "hello"
print(s)
s1  = "'hello'"
s2 = '"hello"'

s3 = """ hello
              Welcome in SCS
         """

print(s1)
print(s2)
print(s3)
