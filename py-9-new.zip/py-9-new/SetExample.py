#x = {"C","C++","JAVA","PYTHON","PHP","C","C++",".NET"}
x = set()
x.add("C")
x.add("C++")
x.add("JAVA")
x.add("Python")
for data in x:
    print(data)

a = {1,2,3,4,4,7,8,5}
b =  {2,3,7,8,9}
c= a.union(b)
print(c)
c= a.intersection(b)
print(c)
c= a.difference(b)
print(c)

m=0
for data in a:
    if m<data:
        m=data
print(m)        

