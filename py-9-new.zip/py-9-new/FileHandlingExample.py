f = open("asd12.txt","a+")  #open or Create then append
name = input("Enter name")
email = input("Enter email")
f.write("\n name is "+name+ "\n email is "+email )
data = f.read()
print(data)
f.close()
