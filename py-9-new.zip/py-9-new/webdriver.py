from selenium import webdriver

browser = webdriver.ChromeDriver()
browser.get('http://selenium.dev/')
