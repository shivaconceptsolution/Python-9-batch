salary = int(input("Enter salary of employee"))
if salary<10000:
    salary = salary+500

    
print(salary)

    
