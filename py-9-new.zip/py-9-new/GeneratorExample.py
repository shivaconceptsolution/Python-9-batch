def fun():
    print("Ram")
    yield
    print("Shyam")
    yield
    print("Shiv")
    yield
    print("Vishnu")
    yield
    print("Brahma")


x = fun()
try:
 for i in range(5):
   next(x)
except StopIteration:
    pass
    
