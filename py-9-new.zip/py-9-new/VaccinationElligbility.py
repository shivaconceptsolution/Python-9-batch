age = int(input("Enter age"))
dom = bool(input("Are you Indian? write 'True and False'"))
prevac = bool(input("Are you vaccinated 'True and False'"))

if age>18 and dom == True and prevac == False:
    print("Elligible for vaccenation")
elif not prevac:
    print("Not elligible because you are prevaccinated")
elif dom:
    print("Not elligible because you are not domicile of India")
else:
    print("You are under 18")
