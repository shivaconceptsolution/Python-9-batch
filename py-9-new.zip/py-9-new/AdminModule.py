class Admin:
    def __init__(self):
        print("Admin Constructor")
    def fun(self):
        print("Welcome in Admin Module")
    def Accept(self,id,name):
        self.id=id
        self.name=name

    def Display(self):
        print("ID is ",self.id," Name is ",self.name)


        
