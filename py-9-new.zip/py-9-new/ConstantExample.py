K = (3.14, "www.shivatutorials.com")
#K[0] = 123
print(K[0],K[1])
