s = "hello"
print(s.capitalize())
print(s.center(8,"*"))

a = ("John", "Charles", "Mike")
b = ("Jenny", "Christy", "Monica", "Vicky")
print(tuple(zip(a,b)))
print(tuple(zip(s)))
