emp = {}
item = int(input("Enter no of employee"))
for i in range(0,item):
    key,value = input("Enter key"),input("Enter value")
    emp.update({key:value})

for d,e in emp.items():
    print(d,e)
    
