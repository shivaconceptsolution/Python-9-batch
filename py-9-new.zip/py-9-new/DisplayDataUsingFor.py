for i in range(1,10,3):   # i=1;i<=10; i++
    print("process"+str(i))
for i in range(10,1,-1):   #i=10;i>=1;i--
    print("process"+str(i))
