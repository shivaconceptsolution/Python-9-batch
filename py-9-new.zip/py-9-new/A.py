class A:
    def fun(self):
        print("old features")
