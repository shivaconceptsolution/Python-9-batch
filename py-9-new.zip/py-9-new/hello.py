print("welcome in Python script")
