p=52000.456
r=2.2
t=2.5
si = (p*r*t)/100
print("%.2f" % si)