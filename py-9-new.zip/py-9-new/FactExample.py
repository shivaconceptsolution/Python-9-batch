num =5
f=1
s= ""
for i in range(num,1,-1):
   f=f*i
   s = s + str(i) + " *"
else:   
 print(s,"1=",f)   
