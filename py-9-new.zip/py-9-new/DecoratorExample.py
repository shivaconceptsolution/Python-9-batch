def funnew(a):
    a()
    print(a)
    print("hello abc")
    return a

@funnew
def fun():
    print("fun")


    


