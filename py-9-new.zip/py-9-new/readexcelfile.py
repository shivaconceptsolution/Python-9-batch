import xlwt
#import xlrd
#f = xlrd.open_workbook("d://book1.xls")
#sheet = f.sheet_by_index(0)
from xlwt import Workbook
  
# Workbook is created
wb = Workbook()
# add_sheet is used to create sheet.
sheet1 = wb.add_sheet('sheet1')
nrow=3
ncol=2
for i in range(0,nrow):
    for j in range(0,ncol):
        sheet1.write(i, j, input("Enter data for cell {0}{1}".format(i,j)))

wb.save('d://book3.xls')
