l = [1,2,[3,4,5,[6,7]]]
A = l[0:2]
B = l[2:]
C=[]
D=[]

for i in B:
    for j in i:
        if type(j).__name__=="int":
               C.append(j)
        else:
            for k in j:
                D.append(k)
            
    


lst = A+C+D

print(lst)
