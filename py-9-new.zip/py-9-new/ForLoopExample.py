k=5
for i in range(1,5): # i=1;i<12; i+=3
    print(k)
    k = k+5
   

for i in range(11): 
    print(i)


for i in range(5,0,-1):
    print(i)
