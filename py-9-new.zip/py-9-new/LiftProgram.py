import time
i=1
while i<=20:
    if i<=5:
        print("Lift Floor " + str(i))
        
    elif i<=10:
        print("Lift Floor " + str(11-i))
    elif i<=15:
        print("Lift Floor " + str(i-10))
    else:
        print("Lift Floor " + str(21-i))
    time.sleep(1)
    i=i+1        
