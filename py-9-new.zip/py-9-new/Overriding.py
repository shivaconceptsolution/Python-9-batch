from abc import ABC,abstractmethod

class Smartphone(ABC):
    @abstractmethod
    def screen(self):
        pass
    @abstractmethod
    def multimedia(self):
        pass
    @abstractmethod
    def software(self):
        pass
    @abstractmethod
    def hardware(self):
        pass

class AndroidPhone(Smartphone):
    def screen(self):
        print("screen size")

    def multimedia(self):
        print("multimedia")

    def software(self):
        print("nougat")

    def hardware(self):
        print("hardware")


class AndroidPhoneNew(AndroidPhone):
    def screen(self):
        print("new Screen")

    def software(self):
        print("orio")






        
        
