import threading
import time
class Table(threading.Thread):
    def __init__(self,num):
        super().__init__()
        self.num = num
    def run(self):
        for i in range(1,11):
            print(str(self.num*i) + " ")
            time.sleep(1)

t = Table(5)
t.start()
t.join()
t1 = Table(9)
t1.start()
