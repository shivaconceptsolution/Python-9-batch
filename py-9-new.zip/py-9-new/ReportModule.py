from EmployeeModule import Employee
from StaffModule import Staff
obj = Employee()
#obj.Accept(1,"Emp1")
obj.Accept1(12000)
#obj.Display()
obj.Display1()
    
obj1 = Staff()
obj1.fun()
obj1.Accept(2,"Staff1")
#obj1.Accept1(5000)
obj1.Accept2(1000)
obj1.Display()
#obj1.Display1()
obj1.Display2()
