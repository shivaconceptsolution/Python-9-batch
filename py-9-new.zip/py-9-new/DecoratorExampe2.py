def createnew(func):     #this will contain only new features
    def innerfun():
        a=100
        b=200
        c=a*b
        print(c)
    return innerfun

             #  createnew(addition)
def addition():
    a=100
    b=200
    c=a+b
    print(c)

addition()
