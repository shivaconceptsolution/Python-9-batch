import os
#os.mkdir("scspython")
os.chdir("scspython")
f = open("ram.txt","w")
f.write("ram , ram , ram")
f.close()
os.remove("ram.txt")
