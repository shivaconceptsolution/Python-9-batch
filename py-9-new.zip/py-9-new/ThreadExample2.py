import threading
import time
def fun():
        for i in range(1,11):
            print("process "+str(i))
            time.sleep(1)


            
t = threading.Thread(target=fun)
t.start()
