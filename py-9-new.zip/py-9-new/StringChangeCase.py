s = "Hello"
s1 = ""
for d in s:
    if ord(d)>=65 and ord(d)<=91:
      s1 = s1 + chr(ord(d)+32)
    else:
      s1 = s1 + chr(ord(d)-32)

print(s1)    
