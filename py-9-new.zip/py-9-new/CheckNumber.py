num = int(input("Enter the number"))
if num>=-9 and num<10:
    print("One digit")
else:
    print("Above one digit")
