username = "sachin1213"
password = "gautam"

if username=="sachin" and password=="gautam":
    print("login successfully")

elif username!="sachin" and password!="gautam":
    print("Invalid username and password")

elif username=="sachin" and password!="gautam":
    print("Invalid password")

else:
    print("Invalid username")
    
    
