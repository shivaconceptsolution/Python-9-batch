class Exam:
    def ExamDuration(self):
        print("3 Hours")

    def ExamPattern(self):
        print("Number System")

    def ExamMode(self):
        print("OFFline")

    def Syllabus(self):
        print("Outdated")


class ExamNew(Exam):
    def ExamPattern(self):
        print("Grade System")

    def ExamMode(self):
        print("ONLINE")



obj = ExamNew()
obj.ExamDuration()
obj.ExamPattern()
obj.ExamMode()
obj.Syllabus()



