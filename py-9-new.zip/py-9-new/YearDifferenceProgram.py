date1 = int(input("Enter First Date in ddmmyyyy"))
date2 = int(input("Enter Last Date in ddmmyyyy"))
y1=date1 % 10000
y2=date2 % 10000

diff = y2-y1
print("Difference between two date in year is ",diff)

