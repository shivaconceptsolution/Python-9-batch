print(10+20)
print(10+20.5)
print(str(10) + "20") 
print(10 + int("20"))

print(2**5)

print(50%10)

a=10
a+=5
a-=2
a*=3
a/=2
a//=4
print(a)


x =  [12,23,34,56,78,89]

if 121 not in x:
    print("It is the member of x")
else:
    print("It is not the member of x")


x = [1,2,3]
y = [1,2,3]
x=y
if x is y:
    print("equall")

else:
    print("Not equall")
    


