# convert list to tuple

x = [1,2,3]
y = tuple(x)
z = list(y)
print(x)
print(y)
print(z)
print(type(x))
print(type(y))
print(type(z))
