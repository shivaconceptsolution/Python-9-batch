import time
class Addition:
    def __init__(self):
        self.a=100
        self.b=200
    def add(self):
        print(self.a+self.b)

    def __del__(self):
        f=open("log.txt","a+")
        f.write("Additon Result is "+str(self.a+self.b))
        f.write("Progrm created date "+ str(time.asctime(time.localtime(time.time()))))
        f.close()
        

obj = Addition()
obj.add()              
del obj              
