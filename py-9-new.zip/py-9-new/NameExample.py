name = input("Enter name")
c=0
v=0
ch = 0
for d in name:
   if ch<ord(d):
       ch = ord(d)
       
   if d in ('a','e','i','o','u'):
       v = v+1
   else:
       c = c+1

print("Total vowel is ",v)
print("Total consonent is ",c)

print("Max char is ",chr(ch))

