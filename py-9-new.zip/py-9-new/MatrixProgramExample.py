x = [[1,2,3,4],[4,5,2],[1,2]]

for r in x:
    for c in r:
        print(c,end='')
    print()    



    
