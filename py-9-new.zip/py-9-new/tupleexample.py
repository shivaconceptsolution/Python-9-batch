x = (11,"hello",21,"welcome")
#x.append("C")
#x[0]= 101
#del x[0]
y = ("DS","Java","Python")*2

z = x+y

print(z)
for i in range(0,len(x)):
    print(x[i])

    
for data in x:
    print(data)


    
