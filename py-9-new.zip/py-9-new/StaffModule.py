from AdminModule import Admin
from EmployeeModule import Employee
class Staff(Admin):
    def Accept2(self,bonus):
        self.bonus=bonus

    def Display2(self):
        print("Bonus is ",self.bonus)
