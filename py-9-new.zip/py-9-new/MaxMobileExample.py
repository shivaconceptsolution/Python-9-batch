mobile = int(input("Enter mobile number")) #154

maxmobile=0
smaxmobile=0
tmaxmobile=0

while mobile!=0:
    num = mobile%10    #1
    if maxmobile<num:  # 5<1
        tmaxmobie=smaxmobile #0
        smaxmobile=maxmobile #4
        maxmobile=num  # 5
    elif smaxmobile<num: #4<1
        tmaxmobile=smaxmobile
        smaxmobile=num   #
    elif tmaxmobile<num: #0<1
        tmaxmobile=num   #1
    mobile = mobile//10  #0

print(maxmobile,smaxmobile,tmaxmobile)    
    
