ch = 'Z'
asc = ord(ch)
if asc>=48 and asc<=57:
    print("Numeric Char")
elif asc>=65 and asc<=90 or asc>=97 and asc<=122:
    print("Alphabet char")

else:
    print("special")
