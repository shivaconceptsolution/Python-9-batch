a = 'hello'    #inner String
print(a)
a = "hello"    # outer String
print(a)
a = """ welcome in string concept
fbdfhdgf hdhdgfh gdfhgh gfdh ghgfh g j
 fgfgfdg fd

"""
print(a)

print('"hello"')
print("'hello'")

b = True
print(b)
b = False
print(b)

a = 10 + True
print(a)







