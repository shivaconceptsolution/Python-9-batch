student = {'rno':1001,'sname':'xyz','branch':'cs','fees':45000}

student['rno']=1002
del student['rno']

student.update({'fees':55000})
student.update({'sem':'8th'})

for data in student:
    print(data, student[data])
    
flag=True
for k,v in student.items():
    if v==10001:
        print("exist")
        flag=False
    print(k, ' ',v)
    
if flag:
    print("Not Exist")


if 'rno1' in student:
    print("exist")

else:
    print("not exist")
