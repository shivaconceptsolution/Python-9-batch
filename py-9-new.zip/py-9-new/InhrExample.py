class Company:
    def fun(self):
        print("Company Info")
    def accept(self,name):
        self.name=name
    def display(self):
        print(self.name)

class Manager:
    def fun(self):
        print("Manager Info")
    def accept1(self,eid,ename):
        self.eid=eid
        self.ename=ename
    def display1(self):
        print("Id is ",self.eid, " Name is ",self.ename)

class Developer(Manager,Company):
    def accept2(self,salary):
        self.salary=salary
        
    def display2(self):
        print("Salary is ",self.salary)




obj1 = Manager()
#obj1.accept("Kangaroo")
obj1.accept1(1001,"ABC")
#obj1.display()
obj1.display1()

obj2 = Developer()
obj2.fun()
obj2.accept("Kangaroo")
obj2.accept1(1002,"MNO")
obj2.accept2(45000)
obj2.display()
obj2.display1()
obj2.display2()




        
