import xlrd
f = xlrd.open_workbook("d://book1.xls")
sheet = f.sheet_by_index(0)
#s = sheet.cell_value(0,0)
#print(s)
r = sheet.nrows
c = sheet.ncols
print("row",r,"col",c)
for i in range(0,r):
    for j in range(0,c):
        print(sheet.cell_value(i,j),end=' ')
    print()    

