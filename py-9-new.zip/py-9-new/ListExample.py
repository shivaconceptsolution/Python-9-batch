#x = [1,8,"Python", "SCS", 12.345, True]
x = ["C", "C++", "JAVA", "PYTHON"]
x.append("Django")
x.append("ML")
x[1]="CPP"
del x[2]

print(x[0],x[1],x[2])

for i in range(0,len(x)):
    print(x[i])



for item in x:
    print(item)

print(x[2:4])    
print(x[:5])
print(x[2:])
print(x[:])
print(x[-3:-1])

    
