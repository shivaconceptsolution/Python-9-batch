pythonclass = ["Sachin","SUGAM","SURYANSH","LAKSHMI", "SHALU"]


if "Suraj" not in pythonclass:
    print("Exist")
else:
    print("NOT EXIST")



x = [1,2,3]
y = [1,2,3]
x=y
if x is not y:
    print("address is equall")

else:
    print("address is not equall")



    
