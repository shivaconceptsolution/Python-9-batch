def nrange(num):
    print(num)
    if num>=10:
        return 1
    else:
        nrange(num+1)


nrange(1)
