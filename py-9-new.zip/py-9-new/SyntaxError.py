try:
  a = 10
  b='20'
  c = a1+b
  t=(5,2,3)
  t[0]=500
  print eval('six times seven')
  print1(c)
except SyntaxError,err:
    print("Syntax Error")
  
except TypeError:
    print("Type Error")
except NameError:
    print("Name Error")
