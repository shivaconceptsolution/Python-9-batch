def loop():
    x = [2,3,4,5,6,7,9]
    for i in range(len(x)):

        yield x[i]



l=loop()

while True:

    try:

       print(next(l))

    except StopIteration:

        pass
