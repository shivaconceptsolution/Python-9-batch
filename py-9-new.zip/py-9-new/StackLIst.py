MAXSIZE=5
x = []
while True:
    
    op=int(input("Press 1 for Push\n2 for POP\nOther char for Exit\n"))
    if op==1:
      if len(x)<MAXSIZE:  
        item = input("Enter element")
        x.append(item)
      else:
          print("Overflow Error")
    elif op==2:
      if len(x)!=0:  
        print("POP Element is",x[len(x)-1])
        del x[len(x)-1]
      else:
          print("Under Flow ERROR")
          break
      
    else:
        print("Stack is ",x)
        break
      
