for i in range(1,6):
    ch = 65
    for k in range(1,i):
        print(end=' ')
        ch=ch+1
    for j in range(i,6):
       print(chr(ch),end='')
       ch = ch+1
    print()    
