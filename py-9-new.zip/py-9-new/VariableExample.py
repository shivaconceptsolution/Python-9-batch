a = 10  #integer
print(type(a))
a = "Hello"  #String

print(a)

print(type(a))

mobile_number = 901234444
