s = "adhfg djag fhjdg hfjgd jhf gdjfg djg fhd gfhdg jhfgdjfghjdgfhddjh f ghdjsgfhjd gfhjdsg hfj dshf"
c=0
b=True
while b:
    print(s[c])
    c=c+1
    if c==len(s):
        b=False
else:
    print("Normal Termination")
    
    
