num =5
s =  "even" if num%2==0  else "odd"
print(s)
