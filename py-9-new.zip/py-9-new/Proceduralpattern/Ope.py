def Add():    #Default Without Return Type
    a=100
    b=200
    c=a+b
    print(c)


def Sub():   #Default with Return Type
    a=100
    b=20
    c=a-b
    return c


def Multiplication(a,b):   #parametrised without return
    c=a*b
    print(c)


def Division(a=100,b=2):    #parametrised with return type
    c = a/b
    return c


def AddMulti(*a):
    print(a)


x = lambda a:max(a)

