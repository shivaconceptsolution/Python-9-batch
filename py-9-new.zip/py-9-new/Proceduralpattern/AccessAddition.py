import Ope   # include Addition.py file here
Ope.Add()    # Addittion.py.Add()
x=Ope.Sub()
print(x)

Ope.Multiplication(b=100,a=2)
y=Ope.Division(1000,2)
print(y)
Ope.AddMulti(1,3,4,5,6,7,9)

r=Ope.x([10,2,30])
print(r)
