s = "gggggg"
for i in range(0,len(s)//2):
    if s[i]!= s[(len(s)-1-i)]:
        print("Not Pallindrom")
        break
else:
    print("Pallindrom")
