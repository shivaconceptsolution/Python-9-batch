import pickle
f = open("d://coursedetails.txt","rb")
data = pickle.load(f)
print(data)
