import pickle
class Emp:
    companyname="xyz"
    empid= [1001,1003,1007]
    empname=["xyz","abc","mno"]

obj = Emp()
data = pickle.dumps(obj)  # picking process
print(data)

d = pickle.loads(data)    #unpickling process
print(d.companyname)
print(d.empid)
print(d.empname)

    
