class SI:
    def __init__(self):
        print("Constructor")
        
    def accept(self):
        self.p = float(input("Enter P"))
        self.r = float(input("Enter R"))
        self.t = float(input("Enter T"))
    def siprg(self):
        self.accept()
        si = (self.p*self.r*self.t)/100
        print(si)


obj = SI()
obj.siprg()        

obj1 = SI()
obj1.siprg()


obj2 = SI()
obj2.siprg()  
