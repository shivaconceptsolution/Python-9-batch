import pickle
lst = ["C","C++","Java",".NET","PHP"]

f = open("d://coursedetails.txt","wb")

pickle.dump(lst,f)

f.close()
