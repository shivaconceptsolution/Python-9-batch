def displaypricegst(func):
    def func(p):
        print("Price with GST",p+p*0.20)
    return func    
    

@displaypricegst
def displayPrice(price):
    print("Actual price",price)



displayPrice(100)    
