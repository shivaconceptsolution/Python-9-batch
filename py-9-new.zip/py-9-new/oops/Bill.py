class Bill:
    def actualBill(self,amt):
        print("Amount is ",self.amt)
        
