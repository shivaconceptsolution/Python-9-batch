class Add:
    
    def __init__(self,a,b):
        self.a=a
        self.b=b
        print(self.a+self.b)
    def __init__(self):
        self.a=100
        self.b=20
        print(self.a+self.b) 

obj = Add()
obj1 = Add(10,2)
