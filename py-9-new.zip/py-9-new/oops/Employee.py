class Employee:
    def Accept(self,empid,empname,salary):
        self.empid=empid
        self.empname=empname
        self.salary=salary

    def Display(self):
        print("Empid is {0} name is {1} and sal is {2}".format(self.empid,self.empname,self.salary))
        


obj = Employee()
obj.Accept(1,"Manish Kumar",45000)
obj.Display()
obj1 = Employee()
obj1.Accept(2,"Suresh Kumar",35000)
obj1.Display()
