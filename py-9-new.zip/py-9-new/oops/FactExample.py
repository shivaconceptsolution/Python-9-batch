class Fact:
    def Accept(self,num):
        self.num=num
    def Logicfact(self):
        
        self.f=1
        for i in range(self.num,1,-1):
           self.f=  self.f*i
           
    def Display(self):
        print("Result is "+str(self.f))


obj = Fact()
obj.Accept(5)
obj.Logicfact()
obj.Display()

        
