from Bill import Bill
def newBill(amt):
    print("amount is ",amt+amt*0.20)
    
obj = Bill()
obj.actualBill=newBill
obj.actualBill(500)
